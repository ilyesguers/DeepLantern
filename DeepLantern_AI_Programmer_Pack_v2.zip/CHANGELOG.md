# Changelog

## AI Programmer Pack v2 — 2026-10-17
- Added AI-first entrypoint, file map, Codex inspection-only first-session prompt, change checklist, GitHub workflow, handoff template, Studio MCP setup checklist, and asset folder contracts.
- Corrected stale project-state claims that implementation had not started; current live state must be inspected and verified.
- No Roblox place file was modified, saved, or published.
- No GitHub repository upload was performed as part of generating this local pack.

## Starter pack baseline
- Packaged approved GDD Parts 1–10, implementation notes, nine visual reference boards, and initial AI workflow instructions.
