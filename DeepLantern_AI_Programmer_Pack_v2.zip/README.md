# Deep Lantern — AI-ready project workspace

**Status:** preparation package based on the supplied ZIP. This package is not the live Roblox Studio project and does not contain the `.rbxl` place file or generated 3D models.

## Start here
1. Read `PROJECT_STATE.md`.
2. Read `GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt` (readable export) and use the adjacent RTF as the original source document. Parts 1–10 are approved/locked.
3. Read `Docs/IMPLEMENTATION_NOTES.md`.
4. Read `AI_Workflow/AI_AGENT_RULES.md` before changing anything.
5. Use images in `Art/VisualReference/` as visual references, not as ready-made game textures or meshes.

## Safety
- Never overwrite `save.rbxl` or `DeepLantern_Backup_Oct09.rbxl`. Keep the original and backup outside this repository until a deliberate, verified import plan exists.
- Work in a separate copy/branch. No changes to live Studio until the user reviews the plan.
- Do not invent features from reference images. The locked GDD is authoritative.
- No secrets, credentials, account tokens, or private keys in this repository.

## Current contents
- GDD Parts 1–10: original RTF + plain-text export for AI readability.
- Project state: original RTF + normalized text file.
- Implementation clarifications.
- Nine visual reference boards.
- AI workflow rules, Codex handoff template, Roblox UI skill setup, Blender pipeline notes.
- Empty asset/model folders are placeholders only.
