# Deep Lantern — verified handoff state

**Purpose:** this file is a handoff record, not the GDD.

## Authority order
1. Approved GDD Parts 1–10.
2. `Docs/IMPLEMENTATION_NOTES.md` for its three cross-part clarifications.
3. Actual current Roblox Studio project for what exists and works.
4. This file for the latest verified handoff.

## Known project context (must be re-verified in Studio)
- This is an existing Roblox game project, not a blank new game. Prior sessions describe station, submarine/dive, resource/lifecycle, scanning/Codex and HUD work. Do not assume these are all currently functional without inspection.
- A prior HUD pass changed only `StarterPlayer.StarterPlayerScripts.Client.Controllers.DiveHUDController` and checked desktop/mobile layout screenshots. The HUD's `DIVE ACTIVE`/RETURNING states, Journal/Debrief toggles, and touch controls were not all verified in that final pass.
- A docking-return issue was intentionally deferred. Do not touch it unless the owner explicitly selects it as the task.
- A previous session left Studio in Edit mode with unsaved HUD changes. This is historical context; inspect the actual currently open Studio state and do not save without approval.
- Protected user files: `save.rbxl` and `DeepLantern_Backup_Oct09.rbxl`. Never overwrite either.

## Locked design
- Parts 1–10 of the GDD are approved and locked. There is no Part 11.
- Exactly two currencies: Credits and Research Data.
- Core loop: PLAN → DIVE → DECIDE → DEBRIEF → UPGRADE → GO DEEPER.
- Active exploration; no idle/passive tycoon currency, loot boxes/gacha, rebirths, full wipes, permanent destruction, or pay-to-win depth progression.
- Fair failure: emergency ballast rescue; unsecured cargo only may be lost.
- MVP zones: Station, Shallows, Kelp Forest, Twilight Reef. Use `Zone_TwilightReef`, not `Zone_2_Twilight_Trench`.
- Compact Docking Ring is MVP; expanded/public/social ring is post-MVP.
- Currents are lightweight scripted/trigger modifiers, not fluid simulation or per-frame physics.
- Solo parity with 2–4 player co-op. Codex stages: Sighted → Scanned → Studied → Mastered.
- Mobile and low-end PC are first-class targets.

## Current phase
**AI preparation and verified project audit.** The source pack has been assembled, but this does not prove the live Studio place is synced with this repository.

## Next required action
Run the inspection-only procedure in `AI_Workflow/CODEX_FIRST_SESSION_PROMPT.md`. Record exact Explorer paths, scripts, remotes, current errors, and test state before changing anything.

## Known risks / not verified
- Current Studio hierarchy and source scripts have not been freshly inspected by this pack.
- Current GitHub repository URL and remote synchronization have not been confirmed.
- This pack does not include the live `.rbxl` file, all live Luau scripts, finished Blender models, or production texture maps.
- Do not mark features complete based on old notes or screenshots alone.

## Handoff format
Every task handoff must list changed files/instances, tests actually run, tests not run, issues, rollback steps, and next task. Update this file only with verified information.
