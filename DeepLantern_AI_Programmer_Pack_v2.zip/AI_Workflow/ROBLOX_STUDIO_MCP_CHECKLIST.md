# Roblox Studio agent connection checklist

Use the official Roblox Studio Agent Plugin repository: https://github.com/Roblox/roblox-studio-agent-plugin

1. Save a separate working copy/version of the place; do not overwrite `save.rbxl` or `DeepLantern_Backup_Oct09.rbxl`.
2. Install the official plugin following its current README. In Studio, enable the Studio MCP server/Quick Connect options described by the current plugin version.
3. Configure the supported client (ChatGPT desktop app, Codex CLI, or compatible Claude client) using the official setup instructions.
4. Start with the inspection-only prompt in `CODEX_FIRST_SESSION_PROMPT.md`.
5. Verify the agent can list open Studio windows/project hierarchy before allowing edits.
6. Never assume GitHub connector alone gives an AI direct access to the live Studio DataModel.

Do not use unofficial scripts or paste secrets into prompts. Setup menu names can change; follow the plugin's current README rather than stale screenshots.
