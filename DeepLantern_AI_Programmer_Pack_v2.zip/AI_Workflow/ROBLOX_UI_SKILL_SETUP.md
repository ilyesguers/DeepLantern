# Roblox UI Skill setup

Upstream project: https://github.com/afrxo/roblox-agent-skills
Skill of interest: `skills/roblox-ui/SKILL.md`

This skill is guidance for an AI agent; it is not a Roblox Studio plugin by itself and does not automatically connect the agent to Studio. Install/use it only through a supported agent workflow and review the repository instructions first.

UI acceptance checklist for Deep Lantern:
- Use Roblox-native responsive UI, not a full-board image as a finished interface.
- Maintain visual hierarchy, readable text, safe margins, and touch targets.
- Test desktop 1920×1080 and 1280×720, mobile landscape, and mobile portrait.
- Respect safe areas and CoreGui/top-bar insets.
- Keep UI readable against dark underwater scenes; verify contrast.
- Resource indicators must use actual live values and not invented values.
- Do not add radar/depth features unless their data and behavior are specified in the GDD/current project.
- Test keyboard/mouse and touch; list what was not tested.
