# Change checklist — Deep Lantern

## Before editing
- [ ] Read the AI start file, GDD, implementation notes, agent rules and current state.
- [ ] Verify current repository branch and working tree; do not discard user changes.
- [ ] Verify the exact Studio place and current mode.
- [ ] Make or confirm a separate working copy/version; original and named backup remain untouched.
- [ ] List exact files/instances to change and explicitly list protected areas.
- [ ] Define visible acceptance criteria and rollback.
- [ ] Get user approval for the plan.

## During editing
- [ ] Keep the task narrow; no unrelated refactor.
- [ ] Follow server/client responsibilities and server-authoritative validation.
- [ ] Avoid unnecessary loops, remotes, heavy particles, fluid simulation and expensive AI.
- [ ] Keep mobile/low-end PC support in scope.
- [ ] Reuse approved art direction and existing asset IDs where relevant.

## After editing
- [ ] Run relevant Studio test/playtest; record exactly what was tested.
- [ ] Check Output for new errors/warnings.
- [ ] Capture screenshots at appropriate desktop/mobile sizes for UI tasks.
- [ ] Report changed paths/instances, behavior, tests passed/failed/not run, known risks, rollback.
- [ ] Update `PROJECT_STATE.md` and `CHANGELOG.md` only with verified facts.
- [ ] Leave saving/publishing to the user unless explicitly authorized.
