# Codex task template — Deep Lantern

Copy this template for each implementation task. Fill every bracket before executing.

```text
You are implementing one scoped task in the existing Roblox game Deep Lantern.

Read first, in order:
1. PROJECT_STATE.md
2. GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt
3. Docs/IMPLEMENTATION_NOTES.md
4. AI_Workflow/AI_AGENT_RULES.md

Task: [one small, testable outcome]
Why: [player-facing goal and GDD link]
Target files/instances: [exact paths; if unknown, inspect and report before editing]
New assets: [exact filenames, formats, sizes, import settings]
Do not touch: [protected scripts/instances/files]
Acceptance criteria: [observable pass/fail list]
Test plan: [Studio playtest and device sizes, as applicable]
Rollback: revert only this task's changes; do not overwrite save.rbxl or DeepLantern_Backup_Oct09.rbxl.

Rules:
- Do not begin edits until you have inspected the existing project and listed the planned changes.
- If a requirement conflicts with the locked GDD, stop and explain the conflict.
- No unrelated refactors or invented features.
- Do not create a new mechanic from a visual reference alone.
- After changes, report exact files/instances changed, tests actually run, tests not run, screenshots/evidence if available, and rollback steps.
- Update PROJECT_STATE.md and CHANGELOG.md only after the user reviews/approves the implementation result.
```
