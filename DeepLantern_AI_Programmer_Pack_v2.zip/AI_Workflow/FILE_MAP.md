# File map and asset contract

| Path | Purpose | Authority |
|---|---|---|
| `GDD/DeepLantern_GDD_Parts_1-10_APPROVED.rtf` | Original approved GDD | Design source of truth |
| `GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt` | Readable text export for AI | Same content; verify against RTF if a conversion issue appears |
| `PROJECT_STATE.md` | Implementation handoff | Must match verified reality; never overrides GDD |
| `Docs/IMPLEMENTATION_NOTES.md` | Three specific ambiguity resolutions | Clarifications only |
| `Art/VisualReference/*.png` | Art direction and reference boards | Visual inspiration, not implementation specs by themselves |
| `Roblox/` | Instructions and future project integration notes | Do not assume live scripts are present here |
| `Blender/` | Model/export pipeline | No finished models implied |
| `AI_Workflow/` | Agent rules, prompts, setup and checklists | Required before agent work |
| `CHANGELOG.md` | Human-readable change history | Update after approved changes |

## Naming and output rules
- Use ASCII, descriptive filenames; avoid ambiguous duplicates and `final-final` names.
- For each new model, create `Assets/Models/<ModelName>/` with `.blend`, export, preview, and `README.md`.
- For each new texture, create `Assets/Textures/<AssetName>/` with source, exported image, dimensions, color space, intended use, and license/source notes.
- For UI, keep editable Roblox UI instances/scripts as the implementation; reference boards are not full-screen UI textures.
- For scripts, record exact Roblox Explorer path and whether each script is server/client/shared.
- Do not put binary `.rbxl` files into normal Git history casually; keep original/backups separately. Consider Git LFS only after the owner agrees to the repository strategy.
