# GitHub workflow for Deep Lantern

## Branch strategy
- `main`: approved, stable handoff files only.
- `work/<short-task-name>`: optional isolated task branch for changes that need review.
- Commit one logical change at a time. Use pull requests when practical.

## Review rule
AI-generated changes are proposals until the owner reviews them. For code and docs, show the diff and summarize risk. For UI/art assets, include preview and import notes. Never merge/publish automatically.

## Keep out of Git
- passwords, API tokens, `.env`, private keys, account recovery details.
- temporary caches, macOS `__MACOSX`/`._*` metadata, build outputs.
- the original `save.rbxl` and backup file unless the owner explicitly approves a binary storage strategy.

## Binary policy
Visual reference PNGs are appropriate to version in the repository. Large editable `.blend`, exported models, and texture sources can be stored if repository size permits. Use Git LFS for large binary assets only after deciding the plan and checking limits. GitHub source control does not automatically sync the live Studio DataModel.
