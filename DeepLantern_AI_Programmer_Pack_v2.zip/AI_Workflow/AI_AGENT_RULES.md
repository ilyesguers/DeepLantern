# AI Agent Rules — Deep Lantern

## Required reading order
1. `/PROJECT_STATE.md`
2. `/GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt`
3. `/Docs/IMPLEMENTATION_NOTES.md`
4. relevant visual references under `/Art/VisualReference/`

## Authority
- GDD Parts 1–10 are approved/locked and authoritative. Do not rewrite them.
- Implementation notes resolve only the three documented cross-part ambiguities.
- Project state describes implementation reality and must be updated at handoff. If it conflicts with the GDD on design, the GDD wins; if it records actual existing code/object names, inspect the live project before changing them.
- Ask for clarification rather than inventing missing systems.

## Locked design rules
- Exactly two currencies: Credits and Research Data.
- Core loop: PLAN → DIVE → DECIDE → DEBRIEF → UPGRADE → GO DEEPER.
- Knowledge over RNG; active exploration over passive/idle tycoon income.
- No loot boxes/gacha, rebirths, full wipes, permanent destruction, P2W depth progression, or Robux sales of Research Data/high-tier power stats.
- No grid inventory or weight-ratio math.
- Fair failure uses emergency ballast rescue and loses unsecured cargo only.
- Tone is wonder/curiosity with atmospheric mystery, not horror; no jump scares or gore.
- MVP zones: Station, Shallows, Kelp Forest, Twilight Reef. Use `Zone_TwilightReef`, not `Zone_2_Twilight_Trench`.
- Compact Docking Ring is MVP; expanded/public/social ring is post-MVP.
- Currents are lightweight scripted/trigger modifiers; no fluid simulation or per-frame environmental physics.
- Solo parity with 2–4 player co-op. Codex stages: Sighted → Scanned → Studied → Mastered.
- Keep mobile and low-end PC first-class.

## Change safety
- Never edit, replace, or save over the user's original `save.rbxl`. Never overwrite `DeepLantern_Backup_Oct09.rbxl`.
- Do not modify the live place or Studio state until explicitly asked. Make a plan and list exact target files/instances first.
- Keep scope small; do not refactor unrelated scripts. Do not create new gameplay systems from visual inspiration alone.
- Before editing: report files/instances to be changed and risks. After editing: list exact changes, tests performed, tests not performed, and rollback instructions.
- Never claim a test passed unless it was actually run.
- Keep generated assets organized and record source, dimensions, intended use, import settings, and license/source where known.
- Do not commit credentials or secrets.

## Visual direction
Use the reference boards as art-direction references: deep-ocean dark navy/blue, restrained cyan/bioluminescent accents, legible silhouettes, purposeful station machinery, consistent materials and scale. Do not directly use a full reference board as a UI texture. Design production UI with responsive Roblox UI objects and test landscape/portrait.

## Handoff requirement
Every completed task must update `PROJECT_STATE.md` and `CHANGELOG.md`, including what changed, exact paths/instances, verification, known issues, and next step. Never mark a task complete if assets or source files are missing.
