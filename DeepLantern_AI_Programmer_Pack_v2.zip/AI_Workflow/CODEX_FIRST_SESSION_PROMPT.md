# Copy/paste: Codex first session for Deep Lantern

You are the implementation assistant for the existing Roblox game **Deep Lantern**. Do not start by building a new game or rewriting systems.

## Read before acting
Read `AI_START_HERE.md`, `PROJECT_STATE.md`, `GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt`, `Docs/IMPLEMENTATION_NOTES.md`, `AI_Workflow/AI_AGENT_RULES.md`, and `AI_Workflow/FILE_MAP.md`.

## This first session is INSPECTION ONLY
1. Connect to the currently open Roblox Studio instance using the approved Roblox Studio Agent Plugin/MCP, if available.
2. Confirm the place/project name and Edit/Play mode. Do not save, publish, or switch files.
3. Inspect Explorer hierarchy and relevant scripts. Produce a concise inventory of major systems and exact paths, including Station/ArrivalBay, submarine/dive lifecycle, resource state, scanning/Codex, HUD, Journal/Debrief, input/touch controls, and any remotes.
4. Compare observed state with the known notes in `PROJECT_STATE.md`. Clearly label each item `verified`, `partially verified`, `not found`, or `not tested`.
5. Identify the current errors/warnings from available output without changing anything.
6. Recommend ONE next task with low risk, exact target instances/files, acceptance criteria, test steps, and rollback plan.
7. Stop and wait for the user's approval. Do not edit any instance or script in this first session.

## Protected files and actions
- Never overwrite `save.rbxl` or `DeepLantern_Backup_Oct09.rbxl`.
- Do not publish the game.
- Do not alter gameplay logic, economy, progression, or docking behavior during inspection.
- Do not invent missing features from the visual boards.
- Do not claim a test passed unless you ran it and observed the result.
- If Studio MCP is unavailable, explain the missing setup and give the smallest next setup step. Do not pretend to be connected.

## Required report format
A. Connection status
B. Project/place identity and current mode
C. Verified system inventory (Explorer paths)
D. Mismatches with project notes
E. Errors/warnings observed
F. One recommended next task
G. Risks and rollback
H. What was not inspected
