# DEEP LANTERN — AI PROGRAMMER START HERE

Read this file first. This repository is the project's handoff pack, not the live Roblox place file.

## Required reading order
1. `PROJECT_STATE.md` — current known state and safe next step.
2. `GDD/DeepLantern_GDD_Parts_1-10_APPROVED.txt` — authoritative locked design.
3. `Docs/IMPLEMENTATION_NOTES.md` — three cross-part clarifications.
4. `AI_Workflow/AI_AGENT_RULES.md` — non-negotiable implementation rules.
5. `AI_Workflow/FILE_MAP.md` — where things belong.
6. The relevant board(s) in `Art/VisualReference/`.
7. `AI_Workflow/CODEX_FIRST_SESSION_PROMPT.md` before using Codex against Studio.

## What this pack is
It packages design documents, handoff rules, reference boards, and implementation workflow so an AI programmer can understand the project consistently. It does **not** contain the live `.rbxl` place, a verified export of every live script, production-ready textures, or finished Blender models.

## Current reality and uncertainty
Previous work indicates an existing Roblox Studio place with station, sub/dive, resource/lifecycle and HUD work already present. The current live DataModel and script contents have not been inspected by this pack itself. Therefore, agents must inspect the current project before editing and must not trust an old statement that implementation has not started.

Last known HUD-specific notes: `DiveHUDController` received responsive layout polish; screenshots were checked at desktop and several mobile aspect ratios. `DIVE ACTIVE`, RETURNING, journal/debrief toggles, and touch controls were not all verified in the last pass. The docking-return issue was deliberately deferred. These are leads to verify, not proof of current state.

## Golden rule
First inspect and report; then propose a small scoped change; wait for user approval; only then edit and test. Do not overwrite the original `save.rbxl` or `DeepLantern_Backup_Oct09.rbxl`.
