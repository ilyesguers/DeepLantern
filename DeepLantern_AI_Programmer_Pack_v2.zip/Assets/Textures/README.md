# Textures folder

The supplied PNG boards are visual references, not production texture maps. Do not apply a whole board as a texture to a part. For each generated texture, store the source file and exported version with a README stating pixel dimensions, color space, target object/material, tiling/UV assumptions, transparency, compression/import settings, and source/license. Generate actual game textures only for an explicitly approved asset.
