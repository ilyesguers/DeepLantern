# Models folder

No production-ready Blender models are included yet. For each approved model, use `Assets/Models/<ModelName>/` and include:
- editable `.blend` source;
- exported `.fbx` or agreed import format;
- `preview.png`;
- `README.md` documenting dimensions/scale, pivot, materials, texture references, collision approach, polygon/triangle estimate, export settings, and origin/license.

Begin with one small prop after the pipeline is verified. Do not create a full station or submarine model before the user approves a visual target and scope.
