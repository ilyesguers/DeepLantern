# Blender asset pipeline

Blender is a separate asset-authoring stage; do not assume it is automatically connected to Codex/Claude.

For each model, create a folder under `Assets/Models/<AssetName>/` containing:
- editable `.blend` source
- exported `.fbx` (or a format agreed for the asset)
- `README.md` with intended use, scale in studs/meters, origin/pivot, triangle count estimate, material/texture list, collision plan, and export settings
- preview PNG
- source/license notes for any third-party inputs

Roblox import checklist:
- sane scale and pivot/origin
- efficient geometry and texture sizes
- separate collision geometry where needed
- materials/textures correctly packed or exported
- verify in Studio before considering complete

Start with one low-risk prop, not a full station or submarine. A Blender MCP bridge is optional and must be separately evaluated/configured; do not install unknown scripts blindly.
